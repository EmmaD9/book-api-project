# book-api-project
A  Node.js web server that both hosts static files such as HTML, and hosts a backend web API from a JSON file about books.
